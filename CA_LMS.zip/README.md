# Library Management System (www.codeaider.com)

1. Clone this repo to your local machine

2. Run composer install

3. Run composer update

4. Copy the .env.example to .env and make sure APP_ENV=local is in there

5. Update .env file with you credentials database info

6. Run php artisan config:cache

7. Register

8. Login(default login email-info@codeaider.com , pw- codeaider)


Template: AdminLTE Bootstrap Admin Dashboard

https://www.codeaider.com
