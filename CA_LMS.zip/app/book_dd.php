<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class book_dd extends Model
{
    //
}
