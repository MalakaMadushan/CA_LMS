<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class member_category extends Model
{
    //
}
