<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class survey_temp extends Model
{
    //
}
