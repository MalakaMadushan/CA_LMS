<div>
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>Version</b> 1.0.1
        </div>
        <strong>Devoloped By &nbsp;<i class="fa fa-heart" aria-hidden="true"></i><a href="https:codeaider.com"> &nbsp;Code Aider-Team</a></strong>
    </footer>
</div>
<?php /**PATH D:\Code Aider\CA_LMS\resources\views/partials/footer.blade.php ENDPATH**/ ?>