<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="<?php echo e(asset('app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/_all-skins.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/AdminLTE.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/jvectormap/jquery-jvectormap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/morris.js/morris.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/Ionicons/css/ionicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
    <link href="https://fonts.googleapis.com/css?family=Raleway&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Buda:300&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('style.css')); ?>" rel="stylesheet">

    

    <!-- Font Awesome -->
    <link href="<?php echo e(asset('bower_components/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <!-- Ionicons -->
    <link href="<?php echo e(asset('bower_components/Ionicons/css/ionicons.min.css')); ?>" rel="stylesheet">
    <!-- DataTables -->
    <!-- Theme style -->
    <link href="<?php echo e(asset('bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">

</head>
<body class="hold-transition skin-blue sidebar-mini wysihtml5-supported" style="height: auto; min-height: 100%;">
<section>
    <div class="wrapper" style="height: auto; min-height: 100%;">
        <div>
                <?php echo $__env->yieldContent('content'); ?>

        </div>
    </div>
</section>


<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('js/demo.js')); ?>"></script>
<script src="<?php echo e(asset('js/adminlte.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-jvectormap-1.2.2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-jvectormap-world-mill-en.js')); ?>"></script>
<script>
    $.widget.bridge('uibutton', $.ui.button);
</script>
<script src="<?php echo e(asset('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/raphael/raphael.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/morris.js/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/jquery-sparkline/dist/jquery.sparkline.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/jquery-knob/dist/jquery.knob.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/moment/min/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/fastclick/lib/fastclick.js')); ?>"></script>

<script src="<?php echo e(asset('bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>


<script type="text/javascript">
   $(document).ready(function() {
    $('#name').val("<?php echo e($selectdata->name); ?>");
    $('#address1').val("<?php echo e($selectdata->address1); ?>");
    $('#address2').val("<?php echo e($selectdata->address2); ?>");
    $('#nic').val("<?php echo e($selectdata->nic); ?>");
    $('#mobile').val("<?php echo e($selectdata->mobile); ?>");
    $('#birthday').val("<?php echo e($selectdata->birthday); ?>");
    $('#description').val("<?php echo e($selectdata->description); ?>");
    $('#registeredDate').val("<?php echo e($selectdata->regdate); ?>");
    $("#category").val("<?php echo e($selectdata->Categoryid); ?>");
    $('input:radio[name="title"]').filter('[value="<?php echo e($selectdata->title); ?>"]').attr('checked', true);
    $('input:radio[name="gender"]').filter('[value="<?php echo e($selectdata->gender); ?>"]').attr('checked', true);


    $('#book_aNo').val("<?php echo e($selectdata->accessionNo); ?>");
    $('#book_isbn').val("<?php echo e($selectdata->isbn); ?>");
    $('#book_title').val("<?php echo e($selectdata->book_title); ?>");
    $('#authors').val("<?php echo e($selectdata->authors); ?>");
    $('#purchase_date').val("<?php echo e($selectdata->purchase_date); ?>");
    $('#edition').val("<?php echo e($selectdata->edition); ?>");
    $('#price').val("<?php echo e($selectdata->price); ?>");
    $('#publishyear').val("<?php echo e($selectdata->publishyear); ?>");
    $('#phydetails').val("<?php echo e($selectdata->phydetails); ?>");
    $('#rackno').val("<?php echo e($selectdata->rackno); ?>");
    $('#rowno').val("<?php echo e($selectdata->rowno); ?>");
    $('#note').val("<?php echo e($selectdata->note); ?>");

    $('#book_category').val("<?php echo e($selectdata->book_category_id); ?>");
    $('#language').val("<?php echo e($selectdata->language_id); ?>");
    $('#publisher').val("<?php echo e($selectdata->publisher_id); ?>");
    $('#phymedium').val("<?php echo e($selectdata->phymedium_id); ?>");
    $('#dewey_decimal').val("<?php echo e($selectdata->dewey_decimal_id); ?>");
    
  } );  
</script>

<!------- function---add modal------------------------ -->
<script>
   
function add_by_modal(rout) {

$('#addModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) 
  var opp = button.data('opp_name') 
  var modal = $(this)
 
  document.getElementById("opp_title").innerHTML = 'Add New '+ opp;
  document.getElementById("opp_lbl").innerHTML = opp;
  document.getElementById("modalform").action = rout;
})
}

</script>

<!-- ---------------------alert Auto Close----------------------- -->
<script>
window.setTimeout(function() {
    $(".alert").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove(); 
    });
}, 1500);

</script>

</body>
</html>
<?php /**PATH D:\Code Aider\CA_LMS\resources\views/layouts/include.blade.php ENDPATH**/ ?>